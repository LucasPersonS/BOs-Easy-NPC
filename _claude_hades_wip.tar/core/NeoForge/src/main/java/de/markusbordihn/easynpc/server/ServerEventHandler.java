/*
 * Copyright 2023 Markus Bordihn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package de.markusbordihn.easynpc.server;

import de.markusbordihn.easynpc.Constants;
import de.markusbordihn.easynpc.compat.CompatConstants;
import de.markusbordihn.easynpc.compat.cobblemon.CobblemonLoader;
import de.markusbordihn.easynpc.compat.easymodelentities.EasyModelEntitiesLoader;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

@EventBusSubscriber(modid = Constants.MOD_ID)
public class ServerEventHandler {

  private ServerEventHandler() {}

  @SubscribeEvent
  public static void handleServerAboutToStartEvent(ServerStartingEvent event) {
    ServerEvents.handleServerStarting(event.getServer());
  }

  @SubscribeEvent
  public static void handleServerStartedEvent(ServerStartedEvent event) {
    ServerEvents.handleServerStarted(event.getServer());
    if (CompatConstants.MOD_COBBLEMON_LOADED) {
      CobblemonLoader.register();
    }
    if (CompatConstants.MOD_EASY_MODEL_ENTITIES_LOADED) {
      EasyModelEntitiesLoader.register();
    }
  }

  @SubscribeEvent
  public static void handleServerAboutToStopEvent(ServerStoppingEvent event) {
    ServerEvents.handleServerStopping(event.getServer());
  }

  @SubscribeEvent
  public static void onServerTick(ServerTickEvent.Post event) {
    ServerEvents.handleServerTick(event.getServer());
  }
}
