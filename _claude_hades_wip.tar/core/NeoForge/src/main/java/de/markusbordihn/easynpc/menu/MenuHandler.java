/*
 * Copyright 2023 Markus Bordihn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package de.markusbordihn.easynpc.menu;

import de.markusbordihn.easynpc.menu.dialog.DialogMenu;
import net.minecraft.world.inventory.MenuType;

public class MenuHandler implements MenuHandlerInterface {

  public MenuHandler() {}

  /** Direct clicks use the same Hades presentation as proximity-opened dialogue. */
  @Override
  public void openDialogMenu(net.minecraft.server.level.ServerPlayer player,
      de.markusbordihn.easynpc.entity.easynpc.EasyNPC<?> npc, java.util.UUID dialogId,
      int pageIndex) {
    de.markusbordihn.easynpc.data.dialog.WorldDialogSessionManager.open(
        player, npc, dialogId, pageIndex);
  }

  @Override
  public MenuType<? extends DialogMenu> getDialogMenuType() {
    return ModMenuTypes.DIALOG_MENU.get();
  }
}
